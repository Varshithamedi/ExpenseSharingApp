import java.util.*;

public class ExpenseManager {
    private Map<String, Double> balances;

    public ExpenseManager() {
        this.balances = new HashMap<>();
    }

    public void addUser(String name) {
        balances.putIfAbsent(name, 0.0);
        System.out.println("User added: " + name);
    }

    public void addExpense(String payer, double amount, String[] participants) {
        if (!balances.containsKey(payer)) {
            System.out.println("Payer not found.");
            return;
        }

        double share = amount / participants.length;
        for (String user : participants) {
            user = user.trim();
            if (!balances.containsKey(user)) {
                System.out.println("User " + user + " not found.");
                return;
            }
            if (!user.equals(payer)) {
                balances.put(user, balances.get(user) - share);
            }
        }
        balances.put(payer, balances.get(payer) + amount - share);
        System.out.println("Expense added.");
    }

    public void showBalances() {
        System.out.println("\nCurrent Balances:");
        for (Map.Entry<String, Double> entry : balances.entrySet()) {
            System.out.println(entry.getKey() + ": " + String.format("%.2f", entry.getValue()));
        }
    }
}