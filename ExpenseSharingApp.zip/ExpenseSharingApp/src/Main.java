import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ExpenseManager manager = new ExpenseManager();

        while (true) {
            System.out.println("\nExpense Sharing App");
            System.out.println("1. Add User");
            System.out.println("2. Add Expense");
            System.out.println("3. Show Balances");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter user name: ");
                    String name = scanner.nextLine();
                    manager.addUser(name);
                    break;
                case 2:
                    System.out.print("Enter payer name: ");
                    String payer = scanner.nextLine();
                    System.out.print("Enter amount: ");
                    double amount = scanner.nextDouble();
                    scanner.nextLine();
                    System.out.print("Enter users to split with (comma separated): ");
                    String[] users = scanner.nextLine().split(",");
                    manager.addExpense(payer, amount, users);
                    break;
                case 3:
                    manager.showBalances();
                    break;
                case 4:
                    System.out.println("Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}