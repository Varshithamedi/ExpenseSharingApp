public class Person {
    private String name;
    private double amountPaid;

    public Person(String name, double amountPaid) {
        this.name = name;
        this.amountPaid = amountPaid;
    }

    public String getName() {
        return name;
    }

    public double getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(double amountPaid) {
        this.amountPaid = amountPaid;
    }
}