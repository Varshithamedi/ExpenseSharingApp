A Java-based CLI application that allows multiple users to add expenses and calculates how much each person owes to others to settle shared costs.

🔧 Features
Add users to the system

Record shared expenses

Automatically split and calculate debts

Display balances in a readable format

Robust input validation and error handling

Fully modular and maintainable codebase

🛠️ Technologies Used
Java (JDK 8 or above)

Console-based UI (CLI)

Ready for optional future enhancements:

SQLite (via JDBC) for database storage

Apache POI for Excel reports

JSON/XML for export/import

Swing/JavaFX for GUI

📁 Project Structure
bash
Copy
Edit
ExpenseSharingApp/
│
├── src/
│   ├── Main.java              # Main entry point with CLI interface
│   ├── ExpenseManager.java    # Core logic for expenses and balances
│   ├── Person.java            # Model class for each user
│
├── README.txt                 # Project documentation
🚀 How to Compile & Run
Open in VS Code or Terminal

Navigate to ExpenseSharingApp/src

Compile the code:

bash
Copy
Edit
javac Main.java ExpenseManager.java Person.java
Run the app:

bash
Copy
Edit
java Main
Follow CLI menu options:

pgsql
Copy
Edit
Expense Sharing App
1. Add User
2. Add Expense
3. Show Balances
4. Exit
🧪 Example Usage
pgsql
Copy
Edit
Choose an option: 1
Enter user name: Alice

Choose an option: 1
Enter user name: Bob

Choose an option: 2
Enter payer name: Alice
Enter amount: 300
Enter users to split with (comma separated): Alice,Bob

Choose an option: 3
Bob owes Alice: ₹150.00
📦 Deliverables
✔️ Source Code (.java files)

✔️ README.txt

⬜ Optional: .jar file (can be added later)

⬜ Optional: SQLite/JSON integration (future scope)

📈 Future Upgrades
GUI with Swing/JavaFX

Persistent data with SQLite

Reports using Apache POI

Export/Import in JSON/XML

